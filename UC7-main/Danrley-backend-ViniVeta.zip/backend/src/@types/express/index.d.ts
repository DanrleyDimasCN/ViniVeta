
declare namespace Express {
    export interface Request {
        usuarioId?: string
    }
}