import React from "react"
import EditarUsuarios from "../../Components/Editar/EditarUsuarios"
import './editar.scss'

export default function Editar() {
    return (
        <div>
            <EditarUsuarios/>
        </div>
    )
}