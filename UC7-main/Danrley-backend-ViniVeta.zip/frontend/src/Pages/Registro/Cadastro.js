import React from "react";
import Cadastrar from "../../Components/Cadastro/Cadastrar";
import './cadastro.scss'
export default function Cadastro() {
    return (
        <div className="box-background-cadastro">
        <Cadastrar/>
        </div>
    )
}