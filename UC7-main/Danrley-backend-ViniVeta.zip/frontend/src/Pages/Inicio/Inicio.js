import React from 'react'
import Login from '../../Components/Login/Login'
import './inicio.scss'

export default function Inicio() {
    return (
      <div className='box-inicio-background'>
          <Login/>
      </div>
    )
}